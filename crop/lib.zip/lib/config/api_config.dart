import 'dart:io';
import 'package:flutter/foundation.dart';

class ApiConfig {
  // Update this with your computer's IP address
  static const String _baseUrl = 'http://192.168.1.5:8000';

  static String get baseUrl {
    if (kIsWeb) {
      // Web can use localhost
      return 'http://localhost:8000';
    } else if (Platform.isAndroid) {
      // Check if running on emulator
      if (_isEmulator()) {
        return 'http://10.0.2.2:8000';
      } else {
        // Physical device
        return _baseUrl;
      }
    } else if (Platform.isIOS) {
      // iOS simulator can use localhost
      if (_isEmulator()) {
        return 'http://localhost:8000';
      } else {
        // Physical device
        return _baseUrl;
      }
    }
    return _baseUrl;
  }

  static bool _isEmulator() {
    // This is a simplified check - you might need to adjust based on your needs
    return Platform.environment.containsKey('ANDROID_HOME') ||
        Platform.environment.containsKey('SIMULATOR_RUNTIME_VERSION');
  }

  // API Endpoints
  static const String predictEndpoint = '/predict';
  static const String healthEndpoint = '/health';
  static const String availableCropsEndpoint = '/available-crops';
}
