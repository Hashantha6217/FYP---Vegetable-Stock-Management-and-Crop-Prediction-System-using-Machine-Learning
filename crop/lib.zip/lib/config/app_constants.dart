class AppConstants {
  // App Info
  static const String appTitle = 'Crop Prediction System';

  // Error Messages
  static const String connectionError = 'Connection Error';
  static const String serverError = 'Server Error';
  static const String invalidInputError = 'Invalid Input';

  // Success Messages
  static const String predictionSuccess = 'Prediction Successful';

  // Date Format
  static const String dateFormat = 'yyyy-MM-dd';

  // Timeouts
  static const Duration apiTimeout = Duration(seconds: 10);

  // UI Messages
  static const String enterRegion = 'Please select a region';
  static const String loadingPrediction = 'Getting prediction...';
  static const String invalidDate = 'Invalid date format';

  // Available Regions
  static const List<String> availableRegions = [
    'Badulla',
    'Hambantota',
    'Kegalle',
    'Matale',
    'Monaragala',
    'Nuwara Eliya',
  ];
}
