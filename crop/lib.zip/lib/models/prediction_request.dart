class PredictionRequest {
  final String region;
  final String date;

  PredictionRequest({
    required this.region,
    required this.date,
  });

  Map<String, dynamic> toJson() {
    return {
      'region': region,
      'date': date,
    };
  }
}
