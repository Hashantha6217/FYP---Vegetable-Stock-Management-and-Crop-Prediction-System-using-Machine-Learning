class PredictionResponse {
  final InputParameters inputParameters;
  final List<VegetableRecommendation> recommendedCrops;
  final String? error;

  PredictionResponse({
    required this.inputParameters,
    required this.recommendedCrops,
    this.error,
  });

  factory PredictionResponse.fromJson(Map<String, dynamic> json) {
    return PredictionResponse(
      inputParameters: InputParameters.fromJson(json['input_parameters']),
      recommendedCrops: (json['recommended_crops'] as List)
          .map((e) => VegetableRecommendation.fromJson(e))
          .toList(),
      error: json['error'],
    );
  }
}

class InputParameters {
  final String region;
  final String date;
  final double temperature;
  final double rainfall;
  final double humidity;
  final String season;

  InputParameters({
    required this.region,
    required this.date,
    required this.temperature,
    required this.rainfall,
    required this.humidity,
    required this.season,
  });

  factory InputParameters.fromJson(Map<String, dynamic> json) {
    return InputParameters(
      region: json['region'],
      date: json['date'],
      temperature: json['temperature'].toDouble(),
      rainfall: json['rainfall'].toDouble(),
      humidity: json['humidity'].toDouble(),
      season: json['season'],
    );
  }
}

class VegetableRecommendation {
  final String name;
  final String confidence;
  final double price;

  VegetableRecommendation({
    required this.name,
    required this.confidence,
    required this.price,
  });

  factory VegetableRecommendation.fromJson(Map<String, dynamic> json) {
    return VegetableRecommendation(
      name: json['name'],
      confidence: json['confidence'],
      price: json['price'].toDouble(),
    );
  }
}
