class WeatherParameters {
  final double temperature;
  final double rainfall;
  final double humidity;

  WeatherParameters({
    required this.temperature,
    required this.rainfall,
    required this.humidity,
  });
}
