import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_constants.dart';
import '../models/prediction_request.dart';
import '../models/prediction_response.dart';
import '../services/api_service.dart';
import '../widgets/prediction_form.dart';
import '../widgets/weather_parameters_card.dart';
import '../widgets/recommended_crops_list.dart';

class CropPredictionScreen extends StatefulWidget {
  const CropPredictionScreen({Key? key}) : super(key: key);

  @override
  State<CropPredictionScreen> createState() => _CropPredictionScreenState();
}

class _CropPredictionScreenState extends State<CropPredictionScreen> {
  final _apiService = ApiService();
  String? _selectedRegion; // Changed from text controller to dropdown selection
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = false;
  PredictionResponse? _predictionResult;
  String? _errorMessage;
  bool _isConnectedToServer = false;

  @override
  void initState() {
    super.initState();
    _checkServerConnection();
  }

  Future<void> _checkServerConnection() async {
    final health = await _apiService.checkHealth();
    setState(() {
      _isConnectedToServer = health['status'] == 'success';
      if (!_isConnectedToServer) {
        _errorMessage = health['message'];
      }
    });
  }

  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _getPrediction() async {
    if (_selectedRegion == null) {
      setState(() {
        _errorMessage = AppConstants.enterRegion;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _predictionResult = null;
    });

    try {
      final request = PredictionRequest(
        region: _selectedRegion!,
        date: DateFormat(AppConstants.dateFormat).format(_selectedDate),
      );

      final response = await _apiService.getPrediction(request);

      setState(() {
        _predictionResult = response;
        _isConnectedToServer = true;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isConnectedToServer = false;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appTitle),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: Icon(
              _isConnectedToServer ? Icons.cloud_done : Icons.cloud_off,
              color: _isConnectedToServer ? Colors.green : Colors.red,
            ),
            onPressed: _checkServerConnection,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PredictionForm(
              selectedRegion: _selectedRegion,
              selectedDate: _selectedDate,
              onDateTap: _pickDate,
              onSubmit: _getPrediction,
              isLoading: _isLoading,
              onRegionChanged: (String? newRegion) {
                setState(() {
                  _selectedRegion = newRegion;
                });
              },
            ),
            if (_errorMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: Card(
                  color: Colors.red.shade100,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        const Icon(Icons.error, color: Colors.red),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            if (_predictionResult != null) ...[
              const SizedBox(height: 16),
              WeatherParametersCard(
                inputParameters: _predictionResult!.inputParameters,
              ),
              const SizedBox(height: 16),
              RecommendedCropsList(
                recommendations: _predictionResult!.recommendedCrops,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
