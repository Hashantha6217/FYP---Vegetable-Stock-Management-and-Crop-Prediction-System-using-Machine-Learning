import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../config/app_constants.dart';
import '../models/prediction_request.dart';
import '../models/prediction_response.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  Future<Map<String, dynamic>> checkHealth() async {
    try {
      final response = await http
          .get(
            Uri.parse('${ApiConfig.baseUrl}${ApiConfig.healthEndpoint}'),
          )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        return {
          'status': 'success',
          'data': jsonDecode(response.body),
        };
      } else {
        return {
          'status': 'error',
          'message': 'Server responded with status ${response.statusCode}',
        };
      }
    } on SocketException {
      return {
        'status': 'error',
        'message': '${AppConstants.connectionError}\n'
            'API URL: ${ApiConfig.baseUrl}\n'
            'Make sure your device and computer are on the same network.',
      };
    } on HttpException {
      return {
        'status': 'error',
        'message': '${AppConstants.serverError}\n'
            'Unable to connect to the server.',
      };
    } catch (e) {
      return {
        'status': 'error',
        'message': 'Unexpected error: $e',
      };
    }
  }

  Future<PredictionResponse> getPrediction(PredictionRequest request) async {
    try {
      final response = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}${ApiConfig.predictEndpoint}'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(request.toJson()),
          )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        return PredictionResponse.fromJson(responseData);
      } else {
        throw Exception(
            'Server error: ${response.statusCode}\n${response.body}');
      }
    } on SocketException {
      throw Exception('${AppConstants.connectionError}\n'
          'Unable to connect to the server.\n'
          'API URL: ${ApiConfig.baseUrl}\n'
          'Please check your network connection.');
    } on HttpException {
      throw Exception('${AppConstants.serverError}\n'
          'HTTP Error occurred.');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<List<String>> getAvailableCrops() async {
    try {
      final response = await http
          .get(
            Uri.parse(
                '${ApiConfig.baseUrl}${ApiConfig.availableCropsEndpoint}'),
          )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<String>.from(data['crops']);
      } else {
        throw Exception('Failed to fetch available crops');
      }
    } catch (e) {
      throw Exception('Error fetching available crops: $e');
    }
  }
}
