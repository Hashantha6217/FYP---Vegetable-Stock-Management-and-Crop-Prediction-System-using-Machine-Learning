import 'package:flutter/material.dart';
import '../models/prediction_response.dart';

class WeatherParametersCard extends StatelessWidget {
  final InputParameters inputParameters;

  const WeatherParametersCard({
    Key? key,
    required this.inputParameters,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Weather Parameters',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            _buildParameterRow(
              icon: Icons.wb_sunny,
              label: 'Season',
              value: inputParameters.season,
              color: _getSeasonColor(inputParameters.season),
            ),
            const SizedBox(height: 8),
            _buildParameterRow(
              icon: Icons.thermostat,
              label: 'Temperature',
              value: '${inputParameters.temperature}°C',
              color: Colors.deepOrange,
            ),
            const SizedBox(height: 8),
            _buildParameterRow(
              icon: Icons.water_drop,
              label: 'Rainfall',
              value: '${inputParameters.rainfall}mm',
              color: Colors.blue,
            ),
            const SizedBox(height: 8),
            _buildParameterRow(
              icon: Icons.cloud,
              label: 'Humidity',
              value: '${inputParameters.humidity}%',
              color: Colors.lightBlue,
            ),
            const SizedBox(height: 8),
            _buildParameterRow(
              icon: Icons.location_on,
              label: 'Region',
              value: inputParameters.region,
              color: Colors.green,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildParameterRow({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(fontSize: 16),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Color _getSeasonColor(String season) {
    switch (season.toLowerCase()) {
      case 'spring':
        return Colors.green;
      case 'summer':
        return Colors.orange;
      case 'fall':
        return Colors.brown;
      case 'winter':
        return Colors.lightBlue;
      default:
        return Colors.grey;
    }
  }
}
